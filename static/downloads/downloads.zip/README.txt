NOTE
1. Untuk kolom timestamps tidak boleh diubah jadi harus menggunakan nama kolom tersebut, isinya disesuaikan dengan data anda
2. Untuk kolom 1 sampai kolom N adalah kolom anda yang akan di deteksi anomali contoh (Pressure, Temperature dll) disesuaikan dengan data anda
3. Paling tidak untuk data latih itu ada (50-100) data, untuk melatih model
4. Untuk data uji maksimal 1000 data

Selamat Mencoba